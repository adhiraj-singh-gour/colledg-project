# Responsive Ecommerce Website Sneakers
## [Watch it on youtube](https://youtu.be/-EM4uVJm9qo)
### Responsive Ecommerce Website Sneakers

- Responsive Ecommerce Website Using HTML CSS JavaScript
- Contains a product page.
- Contains smooth scrolling in each section.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
